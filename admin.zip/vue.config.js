module.exports = {
    publicPath: "http://localhost:8080/"
  };