import Menu from '../../data/menu'

const state = {
  data: Menu.data
}

// getters
const getters = {
}

// mutations
const mutations = {
}

// actions
const actions = {
}

export default {
  namespaced: true,
  state,
  getters,
  actions,
  mutations
}
